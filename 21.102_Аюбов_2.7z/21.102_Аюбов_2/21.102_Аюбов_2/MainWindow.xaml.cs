﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _21._102_Аюбов_2
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnCalc_Click(object sender, RoutedEventArgs e)
        {
            string[] inputText;
            string alphabet = "eyuioaj", maxWord = "", alphabetEng = "qwertyuiopasdfghjklzxcvbnm";
            int Length, maxLength = 0, amount = 0;

            try
            {
                inputText = tbInput.Text.Trim().Split(' ');

                foreach (string word in inputText)
                {
                    Length = word.Length;

                    if (maxLength <= Length)
                    {
                        maxLength = Length;
                        maxWord = word;
                    }


                    foreach (char c in word)
                    {
                        bool eng = false;

                        for (int i = 0; i < alphabetEng.Length; i++)
                        {
                            if (c == alphabet[i])
                            {
                                eng = true;
                                break;
                            }
                        }

                        if (!eng)
                        {
                            throw new Exception();
                        }

                        for (int i = 0; i < alphabet.Length; i++)
                        {
                            if (c == alphabet[i])
                            {
                                amount++;
                                break;
                            }
                        }
                    }

                    tbMaxWord.Text = maxWord;
                    tbAmount.Text = Convert.ToString(amount);
                }
            }
            catch
            {
                MessageBox.Show("Ошибка ввода", "Ошибка ввода", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
